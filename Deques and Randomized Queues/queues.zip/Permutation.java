public class Permutation {
    public static void main(String[] args) {
        //
        Deque<String> deque = new Deque<String>();
        deque.addLast("hello world");
    }
}